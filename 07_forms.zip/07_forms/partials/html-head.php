<?php

require_once("constants.php");
error_reporting(0);
session_start();
error_reporting(ERROR_REPOT_SETTING);
?>
<!DOCTYPE html>

<html>
<head>
    <title><?php echo $pageTitle; ?></title>
    <link rel="stylesheet" href="css/styles.css">
    
    <!-- Fix mobile phone display -->
    <meta name="viewport" content="initial-scale=1, user-scalable=no, minimum-scale=1, maximum-scale=1">

