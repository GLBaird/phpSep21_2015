<?php

// Application Constants

define("DB_HOST",     "localhost");
define("DB_PORT",     "8889");
define("DB_USER",     "root");
define("DB_PASSWORD", "root");
define("DB_NAME",     "addresspro");
define("ERROR_REPOT_SETTING", E_ALL);

// Salt for encryption
define("ENCRYPTION_SALT", "**_PasswordEncryptedWithMagicSpice_**");