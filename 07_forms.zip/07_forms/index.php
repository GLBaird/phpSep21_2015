<?php

header("Location: logon.php");